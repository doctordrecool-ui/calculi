package com.example.minimalcalculator

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.widget.Button
import android.widget.GridLayout
import android.widget.LinearLayout
import android.widget.TextView
import java.math.BigDecimal
import java.math.RoundingMode

class MainActivity : Activity() {
    private lateinit var expressionView: TextView
    private lateinit var resultView: TextView
    private var input = "0"
    private var first: Double? = null
    private var operation: String? = null
    private var freshInput = false
    private var expression = ""

    private val ink = Color.rgb(28, 30, 33)
    private val muted = Color.rgb(135, 139, 145)
    private val pale = Color.rgb(243, 244, 246)
    private val accent = Color.rgb(35, 38, 42)
    private val white = Color.WHITE

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = white
        window.navigationBarColor = white
        window.decorView.systemUiVisibility =
            android.view.View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR or
            android.view.View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR

        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(white)
            setPadding(dp(20), dp(22), dp(20), dp(18))
        }

        val top = TextView(this).apply {
            text = "КАЛЬКУЛЯТОР"
            textSize = 12f
            letterSpacing = .16f
            setTextColor(muted)
            typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
        }
        page.addView(top, LinearLayout.LayoutParams(-1, dp(34)))

        val screen = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.BOTTOM or Gravity.END
            setPadding(dp(4), 0, dp(4), dp(28))
        }
        expressionView = TextView(this).apply {
            text = ""
            textSize = 18f
            setTextColor(muted)
            gravity = Gravity.END
            maxLines = 1
        }
        resultView = TextView(this).apply {
            text = input
            textSize = 54f
            setTextColor(ink)
            gravity = Gravity.END
            maxLines = 1
            includeFontPadding = false
            typeface = Typeface.create("sans-serif-light", Typeface.NORMAL)
        }
        screen.addView(expressionView, LinearLayout.LayoutParams(-1, dp(34)))
        screen.addView(resultView, LinearLayout.LayoutParams(-1, dp(86)))
        page.addView(screen, LinearLayout.LayoutParams(-1, 0, 1f))

        val keys = listOf(
            listOf("AC", "±", "%", "÷"),
            listOf("7", "8", "9", "×"),
            listOf("4", "5", "6", "−"),
            listOf("1", "2", "3", "+"),
            listOf("⌫", "0", ".", "=")
        )
        val grid = GridLayout(this).apply {
            columnCount = 4
            rowCount = 5
            useDefaultMargins = false
        }
        keys.flatten().forEach { key ->
            val isOperator = key in listOf("÷", "×", "−", "+", "=")
            val isUtility = key in listOf("AC", "±", "%", "⌫")
            val button = Button(this).apply {
                text = key
                textSize = if (key == "AC") 17f else 22f
                isAllCaps = false
                setTextColor(if (isOperator) white else ink)
                background = rounded(
                    when {
                        key == "=" -> accent
                        isOperator -> accent
                        isUtility -> pale
                        else -> Color.rgb(250, 250, 250)
                    },
                    22f
                )
                stateListAnimator = null
                elevation = 0f
                setPadding(0, 0, 0, 0)
                setOnClickListener { press(key) }
            }
            val lp = GridLayout.LayoutParams().apply {
                width = 0
                height = dp(68)
                columnSpec = GridLayout.spec(GridLayout.UNDEFINED, 1f)
                setMargins(dp(4), dp(5), dp(4), dp(5))
            }
            grid.addView(button, lp)
        }
        page.addView(grid, LinearLayout.LayoutParams(-1, dp(390)))
        setContentView(page)
        refresh()
    }

    private fun rounded(color: Int, radius: Float) = GradientDrawable().apply {
        setColor(color)
        cornerRadius = dp(radius.toInt()).toFloat()
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private fun refresh() {
        resultView.text = input
        expressionView.text = expression
    }

    private fun press(key: String) {
        when (key) {
            "AC" -> {
                input = "0"; first = null; operation = null
                expression = ""; freshInput = false
            }
            "⌫" -> {
                if (freshInput || input.startsWith("Ошибка")) input = "0"
                else input = if (input.length <= 1 || (input.length == 2 && input[0] == '-')) "0" else input.dropLast(1)
            }
            "±" -> if (input != "0" && !input.startsWith("Ошибка")) {
                input = if (input.startsWith("-")) input.drop(1) else "-$input"
            }
            "%" -> {
                input.toDoubleOrNull()?.let { input = format(it / 100.0) }
                freshInput = true
            }
            "." -> {
                if (freshInput || input.startsWith("Ошибка")) { input = "0."; freshInput = false }
                else if (!input.contains(".")) input += "."
            }
            "+", "−", "×", "÷" -> {
                first = input.toDoubleOrNull()
                operation = key
                expression = "${input} $key"
                freshInput = true
            }
            "=" -> {
                val a = first
                val b = input.toDoubleOrNull()
                val op = operation
                if (a != null && b != null && op != null) {
                    expression = "${format(a)} $op ${format(b)} ="
                    input = if (op == "÷" && b == 0.0) "Ошибка" else format(
                        when (op) {
                            "+" -> a + b
                            "−" -> a - b
                            "×" -> a * b
                            "÷" -> a / b
                            else -> b
                        }
                    )
                    first = null; operation = null; freshInput = true
                }
            }
            else -> if (key.length == 1 && key[0].isDigit()) {
                if (freshInput || input == "0" || input.startsWith("Ошибка")) input = key
                else if (input.length < 16) input += key
                freshInput = false
            }
        }
        refresh()
    }

    private fun format(value: Double): String {
        if (!value.isFinite()) return "Ошибка"
        return BigDecimal.valueOf(value).setScale(8, RoundingMode.HALF_UP)
            .stripTrailingZeros().toPlainString()
    }
}
